package com.mytrip.util.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {

	// JDBC 사용 객체
	public Connection con = null;
	public PreparedStatement pstmt = null;
	public ResultSet rs = null;
	
}
